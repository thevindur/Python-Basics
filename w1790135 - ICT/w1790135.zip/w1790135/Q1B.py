x=int(input("Enter the average weight: "))
y=int(input("Enter the sum of known weights: "))

weight=(10*x-y)/3
print("Weight of the fish that was not recorded: ",round(weight,2))
