phonebook = {}
phonebook["John@abc.com"] = 938477566
phonebook["Jack@abc.com"] = 938377264
phonebook["Jill@abc.com"] = 947662781
phonebook["Will@abc.com"] = 947662783
phonebook["Bill@abc.com"] = 947662782
print(phonebook)
