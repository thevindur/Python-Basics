n=9
m = list(list(range(1*i,(n+1)*i, i)) for i in range(1,n+1))
print("Multiplication Table","\n")
print("1 2 3 4 5 6 7 8 9 ","\n","\n")
print("---------------------------")
for i in m:
    i = [str(j).rjust(len(str(m[-1][-1]))+1) for j in i]
    print(''.join(i))
