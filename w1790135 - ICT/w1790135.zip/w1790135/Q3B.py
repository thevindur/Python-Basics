import timeit
start = timeit.default_timer()

stop = timeit.default_timer()
print('Time: ', stop - start)
