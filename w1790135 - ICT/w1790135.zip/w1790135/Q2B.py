RT=input("Enter the type of room: ")
M=input("Enter the month you wish to make the reservation: ")
D=input("Enter the number of days: ")
N=input("Enter the number of rooms: ")
print("\n")

try:
    D = int(D)
except ValueError:
    print("Please enter integers for number of days and number of rooms")
    import sys
    sys.exit()
 
try:
    N = int(N)
except ValueError:
    print("Please enter integers for number of days and number of rooms")
    import sys
    sys.exit()

c=0
def discount():
    if M=="Jan" or M=="Feb" or M=="March":
        if D<=2:
            
        elif D<=5:
        else:

    elif M=="April" or M=="May" or M=="June":
        if D<=2:
        elif D<=5:
        else:

    elif M=="July" or M=="August" or M=="September":
        if D<=2:
        elif D<=5:
        else:

    elif M=="October" or M=="November" or M=="December":
        if D<=2:
        elif D<=5:
        else:


while (N<=5) and (N!=0):
    if (RT=="Double Room") or (RT=="DR"):
    elif (RT=="Twin Room") or (RT=="TR"):
    elif (RT=="Master Suite") or (RT=="MS"):
    else:
    
