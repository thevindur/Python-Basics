# A – Tuple (Because a tuple is immutable. And since the values of Sinhala alphabet are unchangeable)
# B – List (With the user inputs values may vary. In a List the values can change because it’s mutable
# C – Dictionary
#(Since we have to input the email and telephone number we can use dictionary as it contains key and the value also Dictionary is mutable and unordered so data can be varied)
